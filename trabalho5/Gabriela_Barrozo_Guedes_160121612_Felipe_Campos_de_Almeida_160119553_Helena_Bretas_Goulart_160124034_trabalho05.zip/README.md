# EDA - Trabalho 5

#### Turma A
#### Grupo:
* Felipe Campos de Almeida;
* Gabriela Barrozo Guedes;
* Helena Bretas Goulart;

###### Para compilar o programa rode:
```
gcc -o binary_tree.o -c binary_tree.c
gcc projeto5.c binary_tree.o -lm -o a

```
###### Em seguida rode o comando para executar:

```
./a
```
